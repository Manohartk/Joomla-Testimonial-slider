<?php
/**
 * @package		wisevu
 * @subpackage	mod_wisevu_testimonial
 * @copyright	Copyright (C) 2016 wisevu.com - All rights reserved.
 */

//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
// Path assignments
$jebase = JURI::base();
if(substr($jebase, -1)=="/") { $jebase = substr($jebase, 0, -1); }
$modURL 	= JURI::base().'modules/mod_wisevu_testimonial';
// get parameters from the module's configuration
// $jQuery = $params->get("jQuery");
$Title = $params->get('Title','');

$TestimonialTitle[] = $params->get( '!', "" );
$TestimonialTitleColor[] = $params->get( '!', "" );
$TestimonialContent[]= $params->get( '!', "" );
$TestimonialContentColor[]= $params->get( '!', "" );
$TestimonialAuthor[]= $params->get( '!', "" );
$TestimonialAuthorColor[]= $params->get( '!', "" );
$TestimonialDate[]= $params->get( '!', "" );
$TestimonialDateColor[]= $params->get( '!', "" );
$TestimonialUrlType[]= $params->get( '!', "" );
$TestimonialBgImage[]= $params->get( '!', "" );
$TestimonialBgColor[]= $params->get( '!', "" );


for ($j=1; $j<=10; $j++)
{
  $TestimonialTitle[] = $params->get( 'TestimonialTitle'.$j , "" );
  $TestimonialTitleColor[] = $params->get( 'TestimonialTitleColor'.$j , "" );
  $TestimonialContent[] = $params->get( 'TestimonialContent'.$j , "" );
  $TestimonialContentColor[] = $params->get( 'TestimonialContentColor'.$j , "" );
  $TestimonialAuthor[]= $params->get( 'TestimonialAuthor'.$j , "" );
  $TestimonialAuthorColor[]= $params->get( 'TestimonialAuthorColor'.$j , "" );
  $TestimonialDate[]= $params->get( 'TestimonialDate'.$j , "" );
  $TestimonialDateColor[]= $params->get( 'TestimonialDateColor'.$j , "" );
  $TestimonialUrlType[]= $params->get( 'TestimonialUrlType'.$j , "" );
  $TestimonialBgImage[]= $params->get( 'TestimonialBgImage'.$j , "" );
  $TestimonialBgColor[]= $params->get( 'TestimonialBgColor'.$j , "" );

  
}

$app = JFactory::getApplication();
$template = $app->getTemplate();
$doc = JFactory::getDocument(); //only include if not already included
$doc->addStyleSheet( $modURL . '/css/mod_wisevu_testimonial.css');
$doc->addStyleSheet( $modURL . '/css/bootstrap.min.css');

$doc = JFactory::getDocument();
$js = '';
$doc->addScriptDeclaration($js);




?>


<div class="carousel fade-carousel slide mbr-slider" data-ride="carousel" data-interval="4000" id="bs-carousel">


  <!-- Overlay -->
 <!-- <div class="overlay"></div> -->
    <ol class="carousel-indicators">
        <?php

        $active = 0;

        for ($i=0; $i<=10; $i++){ 
          if ($TestimonialTitle[$i] != null) { ?>  
        <!-- Indicators -->

          <li data-target="#bs-carousel" data-slide-to="<?php echo $i; ?>" class="<?php if($active==0){ echo 'active'; $active= 1; } ?>"></li>


      <?php } 
        }
      ?>
    </ol>
 
  


<!-- Wrapper for slides -->
  <div class="carousel-inner">

    <?php

  $active = 0;
  for ($i=0; $i<=10; $i++){ 
    if ($TestimonialTitle[$i] != null) { ?> 
  
    <div class="item slide <?php if($active==0){ echo 'active'; $active= 1; } ?>">
      <div class="slide-<?php echo $i; ?>"></div>
      <div class="hero hero-<?php echo $i; ?>">
        <hgroup>
      <div class="testimonial-title">
        
        <span class="quote-img"><img src="<?php echo JURI::base(); ?>/modules/mod_wisevu_testimonial/images/testimonial-quote.png"  alt="quote" /></span>
		<h1>
			<span class="mob-slide"><?php echo $TestimonialTitle[$i]; ?></span>
        </h1>
      </div>        
      <div class="testimonial-content">
        <p><?php echo $TestimonialContent[$i]; ?></p>
      </div>
        </hgroup>
      <div class="author-details"><?php echo $TestimonialAuthor[$i]; ?> - <span><?php echo $TestimonialDate[$i]; ?></span></div>
      

	       <div class="star-rating <?php echo$TestimonialUrlType[$i];?>">    </div> 


      </div>
    </div>
	
	

	
	 <?php 
    } //  IF condition
  } //  for loop
?>  


  </div>

<a data-app-prevent-settings="" class="left carousel-control" role="button" data-slide="prev" href="#bs-carousel">
                    <span class="icon-prev" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
</a>

<a data-app-prevent-settings="" class="right carousel-control" role="button" data-slide="next" href="#bs-carousel">
                    <span class="icon-next" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
</a>

</div>

   
<style>
  <?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>    
        .fade-carousel .slide .slide-<?php echo $i; ?>  {
          background-image: url("<?php echo $TestimonialBgImage[$i]; ?>"); 

        }
		.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 480px;
			background-size: cover;
			background-position: center center;
			background-repeat: no-repeat;
		}
		.hero-<?php echo $i; ?> .testimonial-content
		{
			font-weight:300;
		}

  <?php 
      } 
    } 
  ?>
  
  <?php
	for ($i=0; $i<=10; $i++){ 
	  if ($TestimonialTitleColor[$i] != null) { ?>    
		.hero-<?php echo $i; ?> .testimonial-title h1{
		  color: <?php echo $TestimonialTitleColor[$i]; ?>; 
		}
		.hero-<?php echo $i; ?> .testimonial-content
		{
			color: <?php echo $TestimonialContentColor[$i]; ?>;
		}
		.hero-<?php echo $i; ?> .author-details
		{
			color: <?php echo $TestimonialAuthorColor[$i]; ?>;
		}
		.hero-<?php echo $i; ?> .author-details span
		{
			color: <?php echo $TestimonialDateColor[$i]; ?>;
		}
   <?php 
		  } 
		} 
    ?>
  

@media screen and (max-width: 680px) {
	 <?php
		for ($i=0; $i<=10; $i++){ 
		  if ($TestimonialBgColor[$i] != null) { ?>    
			.fade-carousel .slide .slide-<?php echo $i; ?>{
				  background-image: none; 
				  background-color:<?php echo $TestimonialBgColor[$i]; ?>;
			}
	  <?php 
		  } 
		} 
	  ?>
 		.hero h1
	  {
		  font-size:20px;
	  }
}

@media screen and (max-width: 600px) {

	.testimonial-content
	{
		padding:5px 0;
	}
	.fade-carousel .carousel-inner .item {
		height: 540px;
	}
	.testimonial-box .carousel-inner {
		height: 540px;
	}
	.review-section {
		 margin: 40px 0 70px;
	}
	.fade-carousel {
		height: 540px;
	}
	
	<?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>
	  
	  	.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 540px;

		}
	  
	   <?php 
			} 
		} 
	?> 
	
}

@media screen and (max-width: 480px) {
	
	.fade-carousel {
		height: 650px;
	}
	
	.testimonial-box .carousel-inner {
		height: 650px;
	}
	.fade-carousel .carousel-inner .item {
		height: 650px;
	}
	.review-section {
		margin: 40px 0 70px;
	}
	
		<?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>
	  
	  	.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 650px;

		}
	  
	   <?php 
			} 
		} 
	?> 
	
}

@media screen and (max-width: 400px) {
	
	.fade-carousel {
		height: 650px;
	}
	
	.testimonial-box .carousel-inner {
		height: 650px;
	}
	.fade-carousel .carousel-inner .item {
		height: 650px;
	}
	.review-section {
		margin: 10px 0 30px;
	}
	<?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>
	  
	  	.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 650px;

		}
	  
	   <?php 
			} 
		} 
	?>
}

@media screen and (max-width: 360px) {
	
	.fade-carousel {
		height: 800px;
	}
	
	.testimonial-box .carousel-inner {
		height: 800px;
	}
	.fade-carousel .carousel-inner .item {
		height: 800px;
	}
	.review-section {
		margin:70px 0 45px;
	}
	<?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>
	  
	  	.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 800px;

		}
	  
	   <?php 
			} 
		} 
	?>
	
}


@media screen and (max-width: 320px) {
	
	.hero h1 {
		font-size: 16px;
	}
	.testimonial-content {
		font-size: 13px;
		line-height: 1.5;
	}
	.author-details
	{
		font-size:14px;
	}
	.fade-carousel {
		height: 850px;
	}
	
	.testimonial-box .carousel-inner {
		height: 850px;
	}
	.fade-carousel .carousel-inner .item {
		height: 850px;
	}
	.review-section {
		margin:70px 0 45px;
	}
	<?php
    for ($i=0; $i<=10; $i++){ 
      if ($TestimonialTitle[$i] != null) { ?>
	  
	  	.fade-carousel .slide .slide-<?php echo $i; ?>{
			height: 850px;

		}
	  
	   <?php 
			} 
		} 
	?>
	
}

  </style>





